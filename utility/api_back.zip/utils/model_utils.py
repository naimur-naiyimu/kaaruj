import math
import barcode
from barcode.writer import ImageWriter
from io import BytesIO
from django.core.files import File
import qrcode
from PIL import Image, ImageDraw
from decimal import Decimal


def generate_barcode(self, generated_bar_text):
    try:
        EAN = barcode.get_barcode_class('code128')
        ean = EAN(f"{generated_bar_text}", writer=ImageWriter())
        buffer = BytesIO()
        ean.write(buffer)
        self.barcode.save(f"{generated_bar_text}.png",
                        File(buffer), save=False)
    except Exception as e:
        import traceback
        traceback.print_exc()

# def get_code(model_name, prefix="MB"):
#     obj = model_name.objects.order_by('-id').first()
#     prev_id = 0 if obj is None else obj.id
#     current_id = int(prev_id) + 1
#     return f"{prefix}{str(current_id).zfill(6)}"
def get_invoice_code(model_name, prefix="MB"):
    obj = model_name.objects.order_by('-id').first()
    prev_id = 0 if obj is None else obj.id
    current_id = int(prev_id) + 1
    code = f"{prefix}{str(current_id).zfill(6)}"
    
    # Check for duplicates and fix if necessary
    while model_name.objects.filter(number=code).exists():
        current_id += 1
        code = f"{prefix}{str(current_id).zfill(6)}"
    
    return code

def get_code(model_name, prefix="MB"):
    obj = model_name.objects.order_by('-id').first()
    prev_id = 0 if obj is None else obj.id
    current_id = int(prev_id) + 1
    code = f"{prefix}{str(current_id).zfill(6)}"
    
    # Check for duplicates and fix if necessary


def generate_qrcode(self, text):
    text = text.replace("https://", "").replace("http://", "")
    qrcode_img = qrcode.make(text)
    size = qrcode_img.size
    canvas = Image.new('RGB', size, 'white')
    canvas.paste(qrcode_img)
    fname = f'qr_code-{text}.png'
    buffer = BytesIO()
    canvas.save(buffer, 'PNG')
    self.qr_code.save(fname, File(buffer), save=False)
    canvas.close()


from rest_framework.decorators import action
from rest_framework import viewsets, status
from rest_framework.response import Response
import datetime
from coreapp.pagination import paginate




class FilterGivenDateInvoice(viewsets.ModelViewSet):
    @paginate
    @action(detail=False, methods=['get'])
    def filter(self, request, *args, **kwargs):
        start = request.GET.get("start")
        end = request.GET.get("end")
        try:
            start_month, start_day,  start_year = start.split("/")
        except:
            return Response({"data": [], "error": "Start date is empty or Please use correct format,month/date/year"}, status=status.HTTP_404_NOT_FOUND)
        try:
            end_month, end_day,  end_year = end.split("/")
        except:
            return Response({"data": [], "error": "End date is empty or Please use correct format,month/date/year"}, status=status.HTTP_404_NOT_FOUND)
        start_date = datetime.datetime(year=int(start_year), month=int(start_month), day=int(start_day),
                                        hour=0, minute=0, second=0)  # represents 00:00:00
        end_date = datetime.datetime(year=int(end_year), month=int(end_month), day=int(end_day),
                                        hour=23, minute=59, second=59)
        return self.get_queryset().model.objects.filter(invoice_date__range=[start_date, end_date])
