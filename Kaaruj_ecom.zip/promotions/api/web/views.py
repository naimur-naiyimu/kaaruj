
from . import serializers
from ...models import *
from coreapp.helper import *

class OfferAPI(viewsets.ModelViewSet):
    queryset = Offer.objects.all()
    serializer_class = serializers.OfferSerializer
    permission_classes = [AllowAny]
    http_method_names = ['get']

