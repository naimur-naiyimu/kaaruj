
from . import serializers
from ...models import *
from coreapp.models import User
from coreapp.helper import *
from .. import filters as custom_filters

class BIllingInfoAPI(viewsets.ModelViewSet):
    queryset = BillingInfo.objects.all()
    serializer_class = serializers.BillingInfoSerializer
    permission_classes = [AllowAny]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    http_method_names = ['get', 'post']

class CheckoutAPI(viewsets.ModelViewSet):
    queryset = Checkout.objects.all()
    serializer_class = serializers.CheckoutSerializer
    permission_classes = [AllowAny]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    http_method_names = ['get', 'post']

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['request'] = self.request   
        return context

class VerifyCouponAPI(viewsets.ModelViewSet):
    queryset = Coupon.objects.all()
    serializer_class = serializers.VerifyCouponSerializer
    permission_classes = [AllowAny]
    http_method_names = ['post']

    def create(self, request, *args, **kwargs):
        data = request.data
        code = data.get('code')
        try:
            coupon = Coupon.objects.get(code=code, is_active=True)
        except Coupon.DoesNotExist:
            return Response({'error': 'Invalid Coupon Code'}, status=status.HTTP_400_BAD_REQUEST)
 
        return Response({'success': 'Coupon is valid','discount':coupon.discount_amount}, status=status.HTTP_200_OK)