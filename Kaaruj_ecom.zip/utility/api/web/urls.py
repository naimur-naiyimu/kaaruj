from django.urls import path
from rest_framework import routers

from . import views

router = routers.DefaultRouter()
router.register(r"contact-us", views.ContactUsAPI, basename="contact-us")
router.register(r"page", views.PageAPI, basename="page")

urlpatterns = [
    # path("global-settings/", views.GlobalSettingsAPI.as_view())
]
urlpatterns += router.urls
