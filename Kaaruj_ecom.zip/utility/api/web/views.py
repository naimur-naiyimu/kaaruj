
from . import serializers
from ...models import *
from coreapp.models import User
from coreapp.helper import *
from .. import filters as custom_filters

class ContactUsAPI(viewsets.ModelViewSet):

    queryset = Contact.objects.all()
    serializer_class = serializers.ContactSerializer
    permission_classes = [AllowAny]

class PageAPI(viewsets.ModelViewSet):
    queryset = Page.objects.all()
    serializer_class = serializers.PageSerializer
    permission_classes = [AllowAny]
    http_method_names = ['get']
    filterset_class = custom_filters.PageFilter