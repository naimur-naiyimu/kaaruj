
from . import serializers
from ...models import *
from coreapp.models import User
from coreapp.helper import *
from utility.utils.bulk_utils import *
from rest_framework.response import Response
from rest_framework.pagination import LimitOffsetPagination
from coreapp.models import User
from django.utils.decorators import method_decorator
from django.contrib.auth.mixins import PermissionRequiredMixin
from rest_framework.decorators import action
from .serializers import *
class InvoiceViewSet(viewsets.ModelViewSet):
    queryset = Invoice.objects.all()
    serializer_class = InvoiceSerializer
    pagination_class = LimitOffsetPagination
    permission_classes = [AllowAny,]
    
    def get_serializer_class(self):
        print("self.action",self.action)
        if self.action == 'list':
            return InvoiceListSerializer
        elif self.action == 'update':
            return InvoiceSerializer_Update
        elif self.action == 'partial_update':
            return InvoiceSerializer_Update
        else:
            return InvoiceSerializer