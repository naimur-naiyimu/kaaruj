from ...models import *
from rest_framework.serializers import ModelSerializer
from rest_framework import serializers

class InvoiceProductSerializer(ModelSerializer):
    class Meta:
        model = Invoice_Products
        fields = '__all__'
class InvoiceListSerializer(serializers.ModelSerializer):
    prepared_by = serializers.ReadOnlyField(source='created_by.get_full_name')
    class Meta:
        model =  Invoice
        fields = ['id','slug','number','prepared_by','is_custom','delivery_type','delivery_status','payment_status','payment_type','payment_status','total_amount','invoice_date']

  
class InvoiceSerializer(ModelSerializer):
    invoice_products = InvoiceProductSerializer(many=True)
    class Meta:
        model = Invoice
        fields = '__all__'
        read_only_fields = ['slug','number','qr_code','qr_code_text']

    def create(self, validated_data):
        invoice_products = validated_data.pop('invoice_products')
        invoice = Invoice.objects.create(**validated_data)
        for invoice_product in invoice_products:
            created_invoice_product = Invoice_Products.objects.create(invoice=invoice, **invoice_product)
            invoice.invoice_products.add(created_invoice_product)
        return invoice
     
class InvoiceSerializer_Update(ModelSerializer):
    invoice_products_details = serializers.ListField(child=serializers.DictField(),write_only=True)
    invoice_products = InvoiceProductSerializer(many=True,read_only=True)
    class Meta:
        model = Invoice
        fields = '__all__'
        read_only_fields = ['slug','number','qr_code','qr_code_text']

    def update(self,instance, validated_data):
        invoice_products = validated_data.pop('invoice_products_details')
        for invoice_product in invoice_products:
            invoice_product_id = invoice_product.get('id')
            if invoice_product_id:
                inv_prod_instance =Invoice_Products.objects.get(id=invoice_product_id)
                serializer_inv_prod = InvoiceProductSerializer(data=invoice_product,instance=inv_prod_instance,partial=True)
                if serializer_inv_prod.is_valid():
                    serializer_inv_prod.save()
                
            else:
                try:
                    invoice_product['product'] = Products.objects.get(id=invoice_product.get('product'))
                    invoice_product['variant'] = Variant.objects.get(id=invoice_product.get('variant'))
                except Exception as e:
                    print(str(e))
                created_invoice_product = Invoice_Products.objects.create( **invoice_product)
                instance.invoice_products.add(created_invoice_product)
        return instance
     