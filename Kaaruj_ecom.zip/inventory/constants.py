from django.db import models
from django.utils.translation import gettext_lazy as _


# Gender  Options
class MainCategoryChoices(models.IntegerChoices):
    HOME_DECOR = 0, _("Home Decor")
    IN_STYLE = 1, _("In Style")

