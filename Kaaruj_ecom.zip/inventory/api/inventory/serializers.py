from ...models import *
from rest_framework.serializers import ModelSerializer
from rest_framework import serializers

class CategorySerializer(serializers.ModelSerializer):
    
    subcategories = serializers.SerializerMethodField()
    thumb_url = serializers.ReadOnlyField(source='thumb.get_url')
    class Meta:
        model = Category
        # fields = ['id', 'name','level', 'subcategories']
        fields = '__all__'
        read_only_fields = ['slug',]

    def get_subcategories(self, obj):
        subcategories = Category.objects.filter(parent=obj)
        serializer = CategorySerializer(subcategories, many=True)
        return serializer.data
    


    

        
    
class AttributeValueSerializer(serializers.ModelSerializer):
    # attribute_details = AttributeSerializer(source='attribute', read_only=True)]
    class Meta:
        model = AttributeValue
        fields = '__all__'
    
class VariantSerializer(serializers.ModelSerializer):
    # attribute_value_details = AttributeValueSerializer(source='attribute_value', read_only=True,many=True)
    attribute_value = AttributeValueSerializer(many=True)
    class Meta:
        model = Variant
        fields = '__all__'
    


    

class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tags
        fields = '__all__'

class CategorySerializerForProducts(ModelSerializer):
    class Meta:
        model = Category
        # fields = ['id', 'name']
        fields = "__all__"
        lookup_field = 'slug'
        extra_kwargs = {
            'url': {'lookup_field': 'slug'}
        }
        

class ProductSerializerForInvoice(ModelSerializer):
    variants = VariantSerializer(source='variant', read_only=True,many=True)
    class Meta:
        model = Products
        fields = ['id','name','thumb','sku','variants','price','stock',]
    



class ProductCreateUpdateUtils():
    def validate(self, data):
        sku = data.get('sku')
        if self.instance is not None:
            existing_product = Products.objects.filter(sku=sku).exclude(id=self.instance.id).first()
        else:
            existing_product = Products.objects.filter(sku=sku).first()
        if existing_product:
            raise serializers.ValidationError('A product with this SKU already exists.')
        return data

class ProductCreateUpdateUtils():
    # ...

    def create_attributes_values(self, data):
        data = data.get('attribute_value')
        attribute_values = []
        for attribute_value_data in data:
            attribute_id = attribute_value_data.pop('attribute')
            value = attribute_value_data.pop('value')
            attribute = Attributes.objects.get(id=attribute_id)  # Retrieve the attribute instance
            attribute_value_queryset = AttributeValue.objects.filter(attribute=attribute, value=value, **attribute_value_data)
            if attribute_value_queryset.exists():
                attribute_value = attribute_value_queryset.first()
            else:
                attribute_value = AttributeValue.objects.create(attribute=attribute, value=value, **attribute_value_data)
            attribute_values.append(attribute_value)
        return attribute_values

    # ...

    def create_variants(self, data):
        variants = []
        for variant_data in data:
            attribute_values = self.create_attributes_values(variant_data)
            variant_data.pop('attribute_value') #dont need this here
            variant = Variant.objects.create(**variant_data)
            for attribute_value in attribute_values:
                variant.attribute_value.add(attribute_value.id)     
            variants.append(variant)
        return variants
    
    def update_variants(self, data):
        variants = []
        for variant_data in data:
            attribute_values = self.create_attributes_values(variant_data)
            variant_data.pop('attribute_value')  # Don't need this here
            # Get or create the variant based on the variant_data
            # variant = Variant.objects.filter(attribute_value__in=attribute_values,name=variant_data['name'],id__in=instance.variant.all()).first()
            print("variant_data  vchk",variant_data)
            print("attribute_values  vchk",attribute_values)
            variant_id = variant_data.pop('id',None)
            if variant_id is None:
                variant = Variant.objects.create(**variant_data)
            else:
                variant = Variant.objects.get(id=variant_id)

            print("variantchk",variant)
            for attribute_value in attribute_values:
                variant.attribute_value.add(attribute_value)

            variants.append(variant)
        return variants
    
    # def update_variants(self, data,instance):
    #     variants = []
    #     for variant_data in data:
    #         attribute_values = self.create_attributes_values(variant_data)
    #         variant_data.pop('attribute_value')  # Don't need this here
    #         # Get or create the variant based on the variant_data
    #         variant = Variant.objects.filter(attribute_value__in=attribute_values,name=variant_data['name'],id__in=instance.variant.all()).first()
    #         # variant_id = variant_data.pop('id',None)
    #         # variant = Variant.objects.filter(id=variant_id).update(**variant_data)
    #         if variant is None:
    #             variant = Variant.objects.create(**variant_data)
    #         else:
    #             variant = Variant.objects.filter(id=variant.id).update(**variant_data)

    #         for attribute_value in attribute_values:
    #             variant.attribute_value.add(attribute_value.id)

    #         variants.append(variant)
    #     return variants
    
    def create_or_get_tags(self, data):
        tags = []
        for tag_data in data:
            tag_queryset = Tags.objects.filter(name=tag_data['name'])
            if tag_queryset.exists():
                tag = tag_queryset.first()
            else:
                tag = Tags.objects.create(**tag_data)
            tags.append(tag)
        return tags




class ProductSerializer(serializers.ModelSerializer,ProductCreateUpdateUtils):
    # variant_details = VariantSerializer(source='variant', read_only=True,many=True)
    tag_details = TagSerializer(source='tags', read_only=True,many=True)
    category_details = CategorySerializer(source='category', read_only=True,many=True)
    thumb_url = serializers.ReadOnlyField(source='get_thumb_url')
    variant =VariantSerializer(many=True)
    tags = TagSerializer(many=True)
    class Meta:
        model = Products
        fields = '__all__'
        read_only_fields = ['slug','barcode','qrcode']




    def create(self, validated_data):
        variant_data =  self.create_variants(validated_data.pop('variant'))
        tags_data = self.create_or_get_tags(validated_data.pop('tags'))
        categories = validated_data.pop('category')
        product = Products.objects.create(**validated_data)
        product.variant.set(variant_data)
        product.category.set(categories)
        product.tags.set(tags_data)    
        return product
    

  
        
class ProductSerializer_Update(serializers.ModelSerializer,ProductCreateUpdateUtils):
    # variant_update_info = serializers.ListField(child=serializers.DictField(),write_only=True)
    variant_details = VariantSerializer(source='variant', read_only=True,many=True)
    tags = TagSerializer(many=True)

    class Meta:
        model = Products
        fields = '__all__'
        read_only_fields = ['slug','barcode','qrcode']

    def update(self, instance, validated_data):
        # variant_data = validated_data.get('variant_update_info') 
        # print("variant_data",variant_data)
        # if variant_data:
        #     variants = self.update_variants(variant_data)
        #     instance.variant.set(variants)

        tags = validated_data.pop('tags')
        tags_data = self.create_or_get_tags(tags)
        instance.tags.set(tags_data)
        instance.save()
        return instance

class ProductListSerializer(serializers.ModelSerializer):
    thumb_url = serializers.ReadOnlyField(source='get_thumb_url')
    category = serializers.ReadOnlyField(source='category.name')

    class Meta:
        model = Products
        fields = ['id', 'name', 'category', 'stock', 'thumb_url', 'stock', 'slug', 'sku', 'is_active', "updated_at", ]
    




class AttributeSerializer(ModelSerializer):
    class Meta:

        model = Attributes
        fields = "__all__"


class CustomerSerializer(ModelSerializer):
    total_purchase = serializers.ReadOnlyField(source="total")
    count = serializers.ReadOnlyField(source="invoice_count_method")
    class Meta:

        model = Customer
        fields = "__all__"
        lookup_field = 'slug'
        extra_kwargs = {
            'url': {'lookup_field': 'slug'}
        }
        

class CustomerSerializerForInvoice(ModelSerializer):
    class Meta:
        model = Customer
        fields = ['id','name','email','address','mobile']
        # fields = ["id", "name", "email", "mobile", "total_purchase", "status"]
