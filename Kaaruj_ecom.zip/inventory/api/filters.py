from django_filters import rest_framework as rest_filter
from ..models import *
from rest_framework import serializers
class ProductFilter(rest_filter.FilterSet):
    min_price = rest_filter.NumberFilter(field_name='price', lookup_expr='gte')
    max_price = rest_filter.NumberFilter(field_name='price', lookup_expr='lte')

    class Meta:
        model = Products
        fields = ['min_price', 'max_price','category','main_category' ,'tags', 'variant','is_new_arrival','price']