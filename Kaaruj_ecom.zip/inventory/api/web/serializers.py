from inventory.models import *
from rest_framework import serializers
from ...models import *




class CategorySerializer(serializers.ModelSerializer):
    subcategories = serializers.SerializerMethodField()
    class Meta:
        model = Category
        fields = ['id', 'name','level','slug', 'subcategories']

    def get_subcategories(self, obj):
        subcategories = Category.objects.filter(parent=obj)
        serializer = CategorySerializer(subcategories, many=True)
        return serializer.data
    
class AttributeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Attributes
        fields = '__all__'
    
class AttributeValueSerializer(serializers.ModelSerializer):
    attribute_details = AttributeSerializer(source='attribute', read_only=True)
    class Meta:
        model = AttributeValue
        fields = '__all__'
    
class VariantSerializer(serializers.ModelSerializer):
    attribute_value_details = AttributeValueSerializer(source='attribute_value', read_only=True,many=True)

    class Meta:
        model = Variant
        fields = '__all__'

class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tags
        fields = '__all__'

class ProductSerializer(serializers.ModelSerializer):
    variant_details = VariantSerializer(source='variant', read_only=True,many=True)
    tag_details = TagSerializer(source='tags', read_only=True,many=True)
    category_details = CategorySerializer(source='category', read_only=True,many=True)
    thumb_url = serializers.ReadOnlyField(source='get_thumb_url')
    discount_type_text = serializers.ReadOnlyField(source='get_discount_type')
    offer_price = serializers.ReadOnlyField(source='get_offer_price')
    discount = serializers.ReadOnlyField(source='get_discount')
    is_in_wishlist = serializers.SerializerMethodField()

    class Meta:
        model = Products
        fields = '__all__'

    def get_is_in_wishlist(self, obj):
        request = self.context.get('request', None)
        from promotions.models import Wishlist
        if request:
            user = request.user
            if user.is_authenticated:
                return Wishlist.objects.filter(user=user,product=obj).exists()
            else:
                return False
        return False
class ProductListSerializer(serializers.ModelSerializer):
    thumb_url = serializers.ReadOnlyField(source='get_thumb_url')
    discount_type = serializers.ReadOnlyField(source='get_discount_type')
    discount_type_text = serializers.ReadOnlyField(source='get_discount_type_text')
    offer_price = serializers.ReadOnlyField(source='get_offer_price')
    discount = serializers.ReadOnlyField(source='get_discount')
    is_in_wishlist = serializers.SerializerMethodField()

    class Meta:
        model = Products
        fields = ['name','slug','thumb_url','price','stock','id','discount_type_text','discount_type','offer_price','discount','is_in_wishlist']
    
    def get_is_in_wishlist(self, obj):
        request = self.context.get('request', None)
        from promotions.models import Wishlist
        if request:
            user = request.user
            if user.is_authenticated:
                return Wishlist.objects.filter(user=user,product=obj).exists()
            else:
                return False
        return False