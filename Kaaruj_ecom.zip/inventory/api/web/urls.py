from django.urls import path
from rest_framework import routers

from . import views

router = routers.DefaultRouter()
router.register(r"product", views.ProductAPI, basename="products")
router.register(r"category", views.CategoryAPI, basename="category")

urlpatterns = [
    # path("global-settings/", views.GlobalSettingsAPI.as_view())
]
urlpatterns += router.urls
